// Import express
const express = require("express");

// Create app
const app = express();

// Define port
const PORT = 5000;

// Root route
app.get("/", (req, res) => {
  res.send("Welcome to Hello Server 🚀");
});

// About route
app.get("/about", (req, res) => {
  res.send("This is the About Page");
});

// Contact route
app.get("/contact", (req, res) => {
  res.send("Contact us at: contact@example.com");
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
