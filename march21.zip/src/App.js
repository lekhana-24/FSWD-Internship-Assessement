import React, { useState } from "react";
import productsData from "./data/products";
import ProductList from "./components/ProductList";
import Filter from "./components/Filter";

function App() {
  const [products] = useState(productsData);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");

  const filteredProducts = products.filter((product) => {
    return (
      (category === "All" || product.category === category) &&
      product.title.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div>
      <h1>Product Listing UI</h1>
      <Filter setSearch={setSearch} setCategory={setCategory} />
      <ProductList products={filteredProducts} />
    </div>
  );
}

export default App;
