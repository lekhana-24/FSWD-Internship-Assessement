const products = [
  { id: 1, title: "Laptop", price: 50000, category: "Electronics", image: "https://via.placeholder.com/150" },
  { id: 2, title: "T-Shirt", price: 1000, category: "Clothing", image: "https://via.placeholder.com/150" },
  { id: 3, title: "Phone", price: 30000, category: "Electronics", image: "https://via.placeholder.com/150" }
];

export default products;
