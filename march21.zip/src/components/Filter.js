import React from "react";

function Filter({ setSearch, setCategory }) {
  return (
    <div className="filter">
      <input
        type="text"
        placeholder="Search product..."
        onChange={(e) => setSearch(e.target.value)}
      />
      <select onChange={(e) => setCategory(e.target.value)}>
        <option>All</option>
        <option>Electronics</option>
        <option>Clothing</option>
      </select>
    </div>
  );
}

export default Filter;
