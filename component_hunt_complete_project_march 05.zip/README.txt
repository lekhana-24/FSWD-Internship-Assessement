
Assignment Name: Component Hunt

Description:
Break a popular website into reusable UI components and sketch the structure.

Steps:
1. Choose a popular website.
2. Identify major UI sections.
3. Break sections into smaller components.
4. Draw the component hierarchy.

References
React Documentation
https://react.dev/learn/thinking-in-react

MDN Web Docs
https://developer.mozilla.org/en-US/docs/Learn/Tools_and_testing/Client-side_JavaScript_frameworks/Introduction
