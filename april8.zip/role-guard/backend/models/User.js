const mongoose=require('mongoose');
const bcrypt=require('bcryptjs');

const schema=new mongoose.Schema({
 name:{type:String,required:true,trim:true},
 email:{type:String,required:true,unique:true,lowercase:true,match:/.+\@.+\..+/},
 password:{type:String,required:true,minlength:6,select:false},
 role:{type:String,enum:["admin","user"],default:"user"},
 isActive:{type:Boolean,default:true}
},{timestamps:true});

schema.pre('save',async function(next){
 if(!this.isModified('password')) return next();
 this.password=await bcrypt.hash(this.password,10);
 next();
});

schema.methods.comparePassword=function(p){
 return bcrypt.compare(p,this.password);
};

module.exports=mongoose.model("User",schema);
