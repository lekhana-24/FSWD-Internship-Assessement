const User=require('../models/User');
const jwt=require('jsonwebtoken');

const sign=(user)=>jwt.sign({id:user._id,role:user.role},process.env.JWT_SECRET,{expiresIn:"7d"});

exports.register=async(req,res)=>{
 try{
  const user=await User.create(req.body);
  const token=sign(user);
  res.json({token,user});
 }catch(err){
  res.status(400).json({message:"Error"});
 }
};

exports.login=async(req,res)=>{
 const user=await User.findOne({email:req.body.email}).select('+password');
 if(!user||!(await user.comparePassword(req.body.password))){
  return res.status(400).json({message:"Invalid"});
 }
 const token=sign(user);
 res.json({token,user});
};

exports.me=(req,res)=>res.json(req.user);
