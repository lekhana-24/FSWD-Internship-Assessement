const User=require('../models/User');

exports.getAll=async(req,res)=>res.json(await User.find().select('-password'));

exports.getOne=async(req,res)=>res.json(await User.findById(req.params.id).select('-password'));

exports.updateRole=async(req,res)=>{
 const user=await User.findByIdAndUpdate(req.params.id,{role:req.body.role},{new:true});
 res.json(user);
};

exports.toggleStatus=async(req,res)=>{
 const u=await User.findById(req.params.id);
 u.isActive=!u.isActive;
 await u.save();
 res.json(u);
};

exports.delete=async(req,res)=>{
 if(req.user.id===req.params.id) return res.status(400).json({message:"Cannot delete self"});
 await User.findByIdAndDelete(req.params.id);
 res.json({message:"Deleted"});
};

exports.profile=(req,res)=>res.json(req.user);

exports.updateProfile=async(req,res)=>{
 const u=await User.findByIdAndUpdate(req.user.id,{name:req.body.name,email:req.body.email},{new:true});
 res.json(u);
};
