const r=require('express').Router();
const c=require('../controllers/userController');
const auth=require('../middleware/authMiddleware');
const role=require('../middleware/roleMiddleware');

r.get('/',auth,role('admin'),c.getAll);
r.get('/profile',auth,c.profile);
r.put('/profile',auth,c.updateProfile);
r.get('/:id',auth,role('admin'),c.getOne);
r.put('/:id/role',auth,role('admin'),c.updateRole);
r.put('/:id/status',auth,role('admin'),c.toggleStatus);
r.delete('/:id',auth,role('admin'),c.delete);

module.exports=r;
