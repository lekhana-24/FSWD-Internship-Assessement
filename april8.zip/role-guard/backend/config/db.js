const mongoose=require('mongoose');
module.exports=async()=>{
 try{
  await mongoose.connect(process.env.MONGODB_URI);
  console.log("DB connected");
 }catch(err){
  console.error(err.message);
  process.exit(1);
 }
};
