const jwt=require('jsonwebtoken');
const User=require('../models/User');

module.exports=async(req,res,next)=>{
 const header=req.headers.authorization;
 if(!header) return res.status(401).json({message:"No token"});
 const token=header.split(" ")[1];
 try{
  const decoded=jwt.verify(token,process.env.JWT_SECRET);
  const user=await User.findById(decoded.id);
  if(!user||!user.isActive) return res.status(401).json({message:"Unauthorized"});
  req.user=user;
  next();
 }catch{
  res.status(401).json({message:"Invalid token"});
 }
};
