require('dotenv').config();
const express=require('express');
const cors=require('cors');
const connect=require('./config/db');

const app=express();
connect();

app.use(cors());
app.use(express.json());

app.use('/api/auth',require('./routes/authRoutes'));
app.use('/api/users',require('./routes/userRoutes'));

app.listen(5000,()=>console.log("Server running"));
