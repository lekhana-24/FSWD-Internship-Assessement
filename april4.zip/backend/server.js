const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');

const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect('mongodb://127.0.0.1:27017/portfolio');

const UserSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String
});

const FileSchema = new mongoose.Schema({
  filename: String,
  userId: String
});

const User = mongoose.model('User', UserSchema);
const File = mongoose.model('File', FileSchema);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});

const upload = multer({ storage });

app.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  const user = await User.create({ name, email, password: hashed });
  res.json(user);
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).send("User not found");

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.status(400).send("Wrong password");

  const token = jwt.sign({ id: user._id }, "secret");
  res.json({ token });
});

app.post('/upload', upload.single('file'), async (req, res) => {
  const file = await File.create({
    filename: req.file.filename,
    userId: req.body.userId
  });
  res.json(file);
});

app.listen(5000, () => console.log("Server running on 5000"));
