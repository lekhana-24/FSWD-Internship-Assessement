import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [file, setFile] = useState(null);

  const register = async () => {
    await axios.post('http://localhost:5000/register', {
      name: "User",
      email,
      password
    });
    alert("Registered");
  };

  const login = async () => {
    const res = await axios.post('http://localhost:5000/login', {
      email,
      password
    });
    localStorage.setItem('token', res.data.token);
    alert("Logged in");
  };

  const upload = async () => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('userId', '123');

    await axios.post('http://localhost:5000/upload', formData);
    alert("Uploaded");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Auth + Upload</h2>
      <input placeholder="Email" onChange={e => setEmail(e.target.value)} /><br/>
      <input placeholder="Password" type="password" onChange={e => setPassword(e.target.value)} /><br/>
      <button onClick={register}>Register</button>
      <button onClick={login}>Login</button><br/><br/>
      <input type="file" onChange={e => setFile(e.target.files[0])} />
      <button onClick={upload}>Upload</button>
    </div>
  );
}

export default App;
