# Blogging Platform MongoDB Schema

## Collections
- Users
- Posts
- Comments
- Categories
- Likes

## Features
- Scalable schema design
- Proper indexing
- Ready for MVC backend integration

## Usage
1. Install dependencies:
   npm install mongoose

2. Import models in your project:
   const User = require('./models/User');
