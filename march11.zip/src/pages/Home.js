
import React from "react";

function Home(){
return(
<div>
<h2>Home Page</h2>
<p>Welcome to the React Router multi page application.</p>
</div>
);
}

export default Home;
