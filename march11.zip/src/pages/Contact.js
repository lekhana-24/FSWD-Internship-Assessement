
import React from "react";

function Contact(){
return(
<div>
<h2>Contact Page</h2>
<p>Contact page for the application.</p>
</div>
);
}

export default Contact;
