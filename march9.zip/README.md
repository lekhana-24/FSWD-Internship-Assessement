Mood Tracker React App

Steps to run

1. Install Node.js
https://nodejs.org

2. Install dependencies
npm install

3. Run the project
npm run dev

4. Open browser
http://localhost:5173

Features

User selects mood
React useState stores mood
UI updates immediately