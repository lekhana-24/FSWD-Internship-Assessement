import { useState } from "react";

function App() {
  const [mood, setMood] = useState("🙂");

  const moods = [
    { emoji: "😀", label: "Happy" },
    { emoji: "🙂", label: "Neutral" },
    { emoji: "😢", label: "Sad" },
    { emoji: "😡", label: "Angry" },
    { emoji: "😴", label: "Tired" }
  ];

  return (
    <div className="container">
      <h1>Mood Tracker</h1>

      <h2>Your Mood</h2>
      <div className="mood-display">{mood}</div>

      <div className="buttons">
        {moods.map((m) => (
          <button key={m.label} onClick={() => setMood(m.emoji)}>
            {m.emoji} {m.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export default App;