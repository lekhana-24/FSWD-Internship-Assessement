const express = require('express');
const fs = require('fs-extra');
const path = require('path');

const app = express();
app.use(express.json());

const BASE_DIR = path.join(__dirname, 'workspace');

// Ensure workspace exists
fs.ensureDirSync(BASE_DIR);

// Create folder
app.post('/create-folder', async (req, res) => {
    const { folderName } = req.body;
    const folderPath = path.join(BASE_DIR, folderName);
    await fs.ensureDir(folderPath);
    res.send({ message: 'Folder created successfully' });
});

// Create file
app.post('/create-file', async (req, res) => {
    const { fileName, content } = req.body;
    const filePath = path.join(BASE_DIR, fileName);
    await fs.writeFile(filePath, content || '');
    res.send({ message: 'File created successfully' });
});

// Read file
app.get('/read-file', async (req, res) => {
    const { fileName } = req.query;
    const filePath = path.join(BASE_DIR, fileName);
    const data = await fs.readFile(filePath, 'utf-8');
    res.send({ content: data });
});

// Delete file or folder
app.delete('/delete', async (req, res) => {
    const { name } = req.body;
    const targetPath = path.join(BASE_DIR, name);
    await fs.remove(targetPath);
    res.send({ message: 'Deleted successfully' });
});

// List contents
app.get('/list', async (req, res) => {
    const items = await fs.readdir(BASE_DIR);
    res.send({ items });
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});