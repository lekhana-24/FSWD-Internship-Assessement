# Folder Architect

## Description
A Node.js project to create, read, delete, and list files and folders.

## Steps to Run
1. Install dependencies:
   npm install

2. Start server:
   npm start

3. Use Postman or browser to test APIs

## APIs
- POST /create-folder
- POST /create-file
- GET /read-file
- DELETE /delete
- GET /list
