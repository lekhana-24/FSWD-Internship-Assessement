
import React, { useState } from "react";

function App(){

const [email,setEmail]=useState("");
const [password,setPassword]=useState("");
const [errors,setErrors]=useState({});

function validate(){

let newErrors={};

const emailPattern=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;

if(!emailPattern.test(email)){
newErrors.email="Enter valid email";
}

if(password.length<8){
newErrors.password="Password must contain 8 characters";
}

if(!/[A-Z]/.test(password)){
newErrors.password="Password needs one uppercase letter";
}

if(!/[0-9]/.test(password)){
newErrors.password="Password needs one number";
}

setErrors(newErrors);

return Object.keys(newErrors).length===0;
}

function handleSubmit(e){
e.preventDefault();

if(validate()){
alert("Signup successful");
}
}

return(

<div style={{fontFamily:"Arial",padding:40}}>

<h1>Smart Signup Form</h1>

<form onSubmit={handleSubmit}>

<div>
<label>Email</label><br/>
<input
type="text"
value={email}
onChange={(e)=>setEmail(e.target.value)}
/>
<p style={{color:"red"}}>{errors.email}</p>
</div>

<div>
<label>Password</label><br/>
<input
type="password"
value={password}
onChange={(e)=>setPassword(e.target.value)}
/>
<p style={{color:"red"}}>{errors.password}</p>
</div>

<button type="submit">Signup</button>

</form>

</div>

);
}

export default App;
