import React,{useState} from 'react';
import axios from 'axios';

export default function Register(){
 const [email,setEmail]=useState('');
 const [password,setPassword]=useState('');

 const submit=async()=>{
  await axios.post('http://localhost:5000/api/auth/register',{email,password});
  alert('registered');
 }

 return(
  <div>
   <h2>Register</h2>
   <input placeholder="email" onChange={e=>setEmail(e.target.value)}/>
   <input placeholder="password" onChange={e=>setPassword(e.target.value)}/>
   <button onClick={submit}>Submit</button>
  </div>
 );
}
