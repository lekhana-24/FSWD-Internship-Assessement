import React,{useState} from 'react';
import axios from 'axios';

export default function Login(){
 const [email,setEmail]=useState('');
 const [password,setPassword]=useState('');

 const submit=async()=>{
  const res=await axios.post('http://localhost:5000/api/auth/login',{email,password});
  localStorage.setItem('token',res.data.token);
  alert('logged in');
 }

 return(
  <div>
   <h2>Login</h2>
   <input placeholder="email" onChange={e=>setEmail(e.target.value)}/>
   <input placeholder="password" onChange={e=>setPassword(e.target.value)}/>
   <button onClick={submit}>Login</button>
  </div>
 );
}
