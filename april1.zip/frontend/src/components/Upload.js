import React,{useState} from 'react';
import axios from 'axios';

export default function Upload(){
 const [file,setFile]=useState(null);

 const upload=async()=>{
  const fd=new FormData();
  fd.append('file',file);
  await axios.post('http://localhost:5000/api/upload',fd);
  alert('uploaded');
 }

 return(
  <div>
   <h2>Upload</h2>
   <input type="file" onChange={e=>setFile(e.target.files[0])}/>
   <button onClick={upload}>Upload</button>
  </div>
 );
}
