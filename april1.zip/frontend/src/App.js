import React from 'react';
import Register from './components/Register';
import Login from './components/Login';
import Upload from './components/Upload';

export default function App(){
 return(
  <div>
   <h1>Full Project</h1>
   <Register/>
   <Login/>
   <Upload/>
  </div>
 );
}
