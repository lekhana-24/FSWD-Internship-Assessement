const mongoose=require('mongoose');
const bcrypt=require('bcryptjs');

const schema=new mongoose.Schema({
 name:String,
 email:{type:String,unique:true},
 password:{type:String,select:false},
 role:{type:String,default:"user"}
},{timestamps:true});

schema.pre('save',async function(next){
 if(!this.isModified('password')) return next();
 this.password=await bcrypt.hash(this.password,10);
 next();
});

schema.methods.comparePassword=function(p){
 return bcrypt.compare(p,this.password);
};

module.exports=mongoose.model("User",schema);
