const mongoose=require('mongoose');

const schema=new mongoose.Schema({
 name:String,
 email:{type:String,unique:true},
 rollNumber:{type:String,unique:true},
 course:String,
 year:Number,
 gpa:{type:Number,default:0},
 isActive:{type:Boolean,default:true},
 createdBy:{type:mongoose.Schema.Types.ObjectId,ref:"User"}
},{timestamps:true});

module.exports=mongoose.model("Student",schema);
