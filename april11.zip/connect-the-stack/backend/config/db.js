const mongoose=require('mongoose');
module.exports=async()=>{
 try{
  await mongoose.connect(process.env.MONGODB_URI);
  console.log("DB connected");
 }catch(e){
  console.error(e.message);
  process.exit(1);
 }
};
