const r=require('express').Router();
const jwt=require('jsonwebtoken');
const User=require('../models/User');
const auth=require('../middleware/authMiddleware');

const sign=u=>jwt.sign({id:u._id},process.env.JWT_SECRET,{expiresIn:"7d"});

r.post('/register',async(req,res)=>{
 const u=await User.create(req.body);
 res.json({token:sign(u),user:u});
});

r.post('/login',async(req,res)=>{
 const u=await User.findOne({email:req.body.email}).select('+password');
 if(!u||!(await u.comparePassword(req.body.password))) return res.status(400).json({message:"Invalid"});
 res.json({token:sign(u),user:u});
});

r.get('/me',auth,(req,res)=>res.json(req.user));

module.exports=r;
