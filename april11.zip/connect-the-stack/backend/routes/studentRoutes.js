const r=require('express').Router();
const Student=require('../models/Student');
const auth=require('../middleware/authMiddleware');

r.get('/',auth,async(req,res)=>{
 const data=await Student.find().populate('createdBy','name');
 res.json(data);
});

r.post('/',auth,async(req,res)=>{
 const s=await Student.create({...req.body,createdBy:req.user._id});
 res.json(s);
});

r.delete('/:id',auth,async(req,res)=>{
 await Student.findByIdAndDelete(req.params.id);
 res.json({message:"Deleted"});
});

module.exports=r;
