const jwt=require('jsonwebtoken');
const User=require('../models/User');

module.exports=async(req,res,next)=>{
 const h=req.headers.authorization;
 if(!h) return res.status(401).json({message:"No token"});
 try{
  const t=h.split(" ")[1];
  const d=jwt.verify(t,process.env.JWT_SECRET);
  req.user=await User.findById(d.id);
  next();
 }catch{
  res.status(401).json({message:"Invalid"});
 }
};
