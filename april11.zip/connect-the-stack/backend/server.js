require('dotenv').config();
const express=require('express');
const cors=require('cors');
const db=require('./config/db');

const app=express();
db();

app.use(cors());
app.use(express.json());

app.use('/api/auth',require('./routes/authRoutes'));
app.use('/api/students',require('./routes/studentRoutes'));

app.listen(5000,()=>console.log("Server running"));
