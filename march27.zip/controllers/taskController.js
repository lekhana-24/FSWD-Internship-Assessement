const tasks = require('../models/taskModel');

exports.getAllTasks = (req, res) => {
    res.json(tasks);
};

exports.getTaskById = (req, res, next) => {
    const task = tasks.find(t => t.id === parseInt(req.params.id));
    if (!task) return next({ status: 404, message: "Task not found" });
    res.json(task);
};

exports.createTask = (req, res) => {
    const newTask = {
        id: tasks.length + 1,
        title: req.body.title,
        completed: req.body.completed || false
    };
    tasks.push(newTask);
    res.status(201).json(newTask);
};

exports.updateTask = (req, res, next) => {
    const task = tasks.find(t => t.id === parseInt(req.params.id));
    if (!task) return next({ status: 404, message: "Task not found" });

    task.title = req.body.title || task.title;
    task.completed = req.body.completed !== undefined ? req.body.completed : task.completed;

    res.json(task);
};

exports.deleteTask = (req, res, next) => {
    const index = tasks.findIndex(t => t.id === parseInt(req.params.id));
    if (index === -1) return next({ status: 404, message: "Task not found" });

    tasks.splice(index, 1);
    res.json({ message: "Task deleted" });
};
