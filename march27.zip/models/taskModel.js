let tasks = [
    { id: 1, title: "Learn Express", completed: false },
    { id: 2, title: "Build API", completed: true }
];

module.exports = tasks;
