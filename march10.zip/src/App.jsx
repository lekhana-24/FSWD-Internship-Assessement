
import { useState } from "react";

export default function App() {
  const [task, setTask] = useState("");
  const [tasks, setTasks] = useState([]);

  function addTask() {
    if (task.trim() === "") return;
    setTasks([...tasks, task]);
    setTask("");
  }

  function deleteTask(index) {
    const updated = tasks.filter((_, i) => i !== index);
    setTasks(updated);
  }

  return (
    <div style={{fontFamily:"Arial", padding:"30px"}}>
      <h1>Dynamic Task List</h1>

      <input
        type="text"
        value={task}
        placeholder="Enter task"
        onChange={(e) => setTask(e.target.value)}
      />

      <button onClick={addTask} style={{marginLeft:"10px"}}>
        Add Task
      </button>

      <ul>
        {tasks.map((t, index) => (
          <li key={index}>
            {t}
            <button
              onClick={() => deleteTask(index)}
              style={{marginLeft:"10px"}}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
