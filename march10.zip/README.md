
Dynamic List App

Features
Add tasks
Delete tasks
Uses React Hooks (useState)

Run Project

1. Install Node.js
2. Open terminal
3. Run

npm install
npm run dev

Then open the shown localhost link
