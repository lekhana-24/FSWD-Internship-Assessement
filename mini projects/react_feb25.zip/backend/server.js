const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "yourpassword",
  database: "taskdb"
});

db.connect(err => {
  if (err) {
    console.log("DB Error", err);
  } else {
    console.log("DB Connected");
  }
});

app.get("/tasks", (req, res) => {
  db.query("SELECT * FROM tasks", (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result);
  });
});

app.post("/tasks", (req, res) => {
  const { title } = req.body;
  db.query("INSERT INTO tasks (title, status) VALUES (?, 'pending')",
    [title],
    (err) => {
      if (err) return res.status(500).send(err);
      res.json({ message: "Task added" });
    });
});

app.delete("/tasks/:id", (req, res) => {
  db.query("DELETE FROM tasks WHERE id = ?",
    [req.params.id],
    (err) => {
      if (err) return res.status(500).send(err);
      res.json({ message: "Deleted" });
    });
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});
