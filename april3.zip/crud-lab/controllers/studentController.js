const Student = require('../models/Student');

const formatErrors = (err) => {
  if (err.code === 11000) {
    return { error: "Duplicate field value entered" };
  }
  if (err.name === "ValidationError") {
    let errors = {};
    Object.values(err.errors).forEach(e => errors[e.path] = e.message);
    return errors;
  }
  return { error: "Something went wrong" };
};

exports.getAll = async (req, res) => {
  const students = await Student.find();
  res.render('students/index', { students });
};

exports.create = async (req, res) => {
  try {
    const student = await Student.create(req.body);
    res.redirect('/students');
  } catch (err) {
    res.render('students/new', { errors: formatErrors(err), old: req.body });
  }
};

exports.show = async (req, res) => {
  const student = await Student.findById(req.params.id);
  res.render('students/show', { student });
};

exports.update = async (req, res) => {
  try {
    await Student.findByIdAndUpdate(req.params.id, req.body, { runValidators: true });
    res.redirect('/students');
  } catch (err) {
    res.render('students/edit', { errors: formatErrors(err), old: req.body, id: req.params.id });
  }
};

exports.delete = async (req, res) => {
  await Student.findByIdAndDelete(req.params.id);
  res.redirect('/students');
};

exports.apiGetAll = async (req, res) => {
  res.json(await Student.find());
};

exports.apiCreate = async (req, res) => {
  try {
    const student = await Student.create(req.body);
    res.json(student);
  } catch (err) {
    res.status(400).json(formatErrors(err));
  }
};

exports.apiGetOne = async (req, res) => {
  res.json(await Student.findById(req.params.id));
};

exports.apiUpdate = async (req, res) => {
  try {
    const student = await Student.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    res.json(student);
  } catch (err) {
    res.status(400).json(formatErrors(err));
  }
};

exports.apiDelete = async (req, res) => {
  await Student.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted successfully" });
};
