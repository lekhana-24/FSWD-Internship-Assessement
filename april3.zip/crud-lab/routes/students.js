const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/studentController');

router.get('/students', ctrl.getAll);
router.post('/students', ctrl.create);
router.get('/students/:id', ctrl.show);
router.put('/students/:id', ctrl.update);
router.delete('/students/:id', ctrl.delete);

module.exports = router;
