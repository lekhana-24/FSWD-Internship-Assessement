const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/studentController');

router.get('/students', ctrl.apiGetAll);
router.post('/students', ctrl.apiCreate);
router.get('/students/:id', ctrl.apiGetOne);
router.put('/students/:id', ctrl.apiUpdate);
router.delete('/students/:id', ctrl.apiDelete);

module.exports = router;
