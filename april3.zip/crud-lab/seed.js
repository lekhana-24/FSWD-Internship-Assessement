require('dotenv').config();
const mongoose = require('mongoose');
const Student = require('./models/Student');

mongoose.connect(process.env.MONGODB_URI).then(async () => {
  await Student.insertMany([
    { name: "Vivek", email: "vivek@mail.com", rollNumber: "1", course: "Computer Science", year: 3, gpa: 8 },
    { name: "Rahul", email: "rahul@mail.com", rollNumber: "2", course: "IT", year: 2, gpa: 7 }
  ]);
  console.log("Seeded");
  mongoose.disconnect();
});
