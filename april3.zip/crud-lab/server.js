require('dotenv').config();
const express = require('express');
const methodOverride = require('method-override');
const connectDB = require('./config/db');

const app = express();
connectDB();

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(express.static('public'));

app.use(require('./routes/students'));
app.use('/api', require('./routes/api'));

app.use((req, res) => {
  res.status(404).send("Not Found");
});

app.listen(process.env.PORT, () => console.log("Server running"));
