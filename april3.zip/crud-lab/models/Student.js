const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, minlength: 2 },
  email: { type: String, required: true, unique: true, match: /.+\@.+\..+/ },
  rollNumber: { type: String, required: true, unique: true },
  course: {
    type: String,
    enum: ["Computer Science", "Information Technology", "Electronics", "Mechanical", "Civil", "Other"]
  },
  year: { type: Number, min: 1, max: 4, required: true },
  gpa: { type: Number, min: 0, max: 10, default: 0 },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Student', studentSchema);
