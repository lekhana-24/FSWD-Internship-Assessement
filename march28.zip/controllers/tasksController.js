const Task = require('../models/taskModel');

exports.getTasks = (req, res) => {
    const tasks = Task.getAllTasks();
    res.status(200).json(tasks);
};

exports.getTask = (req, res, next) => {
    const task = Task.getTaskById(parseInt(req.params.id));
    if (!task) return next({ status: 404, message: "Task not found" });
    res.status(200).json(task);
};

exports.createTask = (req, res) => {
    const { title, status } = req.body;
    const newTask = { id: Date.now(), title, status };
    const task = Task.createTask(newTask);
    res.status(201).json(task);
};

exports.updateTask = (req, res, next) => {
    const updated = Task.updateTask(parseInt(req.params.id), req.body);
    if (!updated) return next({ status: 404, message: "Task not found" });
    res.status(200).json(updated);
};

exports.deleteTask = (req, res, next) => {
    const deleted = Task.deleteTask(parseInt(req.params.id));
    if (!deleted) return next({ status: 404, message: "Task not found" });
    res.status(200).json({ message: "Task deleted successfully" });
};