let tasks = [
    { id: 1, title: "Learn Node.js", status: "pending" },
    { id: 2, title: "Build API", status: "completed" }
];

const getAllTasks = () => tasks;

const getTaskById = (id) => tasks.find(t => t.id === id);

const createTask = (task) => {
    tasks.push(task);
    return task;
};

const updateTask = (id, updatedData) => {
    const index = tasks.findIndex(t => t.id === id);
    if (index !== -1) {
        tasks[index] = { ...tasks[index], ...updatedData };
        return tasks[index];
    }
    return null;
};

const deleteTask = (id) => {
    const index = tasks.findIndex(t => t.id === id);
    if (index !== -1) {
        return tasks.splice(index, 1);
    }
    return null;
};

module.exports = {
    getAllTasks,
    getTaskById,
    createTask,
    updateTask,
    deleteTask
};