const express = require('express');
const app = express();

const taskRoutes = require('./routes/tasksRoutes');
const errorHandler = require('./middleware/errorHandler');

app.use(express.json());

app.use('/tasks', taskRoutes);

app.use(errorHandler);

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});