const authors = require('../models/authorsModel');

exports.getAllAuthors = (req, res) => {
    res.json(authors);
};

exports.getAuthorById = (req, res, next) => {
    const author = authors.find(a => a.id === parseInt(req.params.id));
    if (!author) return next({ status: 404, message: "Author not found" });
    res.json(author);
};

exports.createAuthor = (req, res) => {
    const newAuthor = {
        id: authors.length + 1,
        name: req.body.name
    };
    authors.push(newAuthor);
    res.status(201).json(newAuthor);
};

exports.updateAuthor = (req, res, next) => {
    const author = authors.find(a => a.id === parseInt(req.params.id));
    if (!author) return next({ status: 404, message: "Author not found" });

    author.name = req.body.name || author.name;

    res.json(author);
};

exports.deleteAuthor = (req, res, next) => {
    const index = authors.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) return next({ status: 404, message: "Author not found" });

    authors.splice(index, 1);
    res.json({ message: "Author deleted" });
};
