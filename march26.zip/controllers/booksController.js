const books = require('../models/booksModel');

exports.getAllBooks = (req, res) => {
    res.json(books);
};

exports.getBookById = (req, res, next) => {
    const book = books.find(b => b.id === parseInt(req.params.id));
    if (!book) return next({ status: 404, message: "Book not found" });
    res.json(book);
};

exports.createBook = (req, res) => {
    const newBook = {
        id: books.length + 1,
        title: req.body.title,
        authorId: req.body.authorId
    };
    books.push(newBook);
    res.status(201).json(newBook);
};

exports.updateBook = (req, res, next) => {
    const book = books.find(b => b.id === parseInt(req.params.id));
    if (!book) return next({ status: 404, message: "Book not found" });

    book.title = req.body.title || book.title;
    book.authorId = req.body.authorId || book.authorId;

    res.json(book);
};

exports.deleteBook = (req, res, next) => {
    const index = books.findIndex(b => b.id === parseInt(req.params.id));
    if (index === -1) return next({ status: 404, message: "Book not found" });

    books.splice(index, 1);
    res.json({ message: "Book deleted" });
};
