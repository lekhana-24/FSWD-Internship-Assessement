const express = require('express');
const booksRoutes = require('./routes/booksRoutes');
const authorsRoutes = require('./routes/authorsRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = 3000;

app.use(express.json());

app.use('/books', booksRoutes);
app.use('/authors', authorsRoutes);

app.get('/', (req, res) => {
    res.send('Route Master Bookstore API Running');
});

app.use(errorHandler);

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
