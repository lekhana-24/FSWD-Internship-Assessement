import {useEffect,useState} from 'react';
import axios from 'axios';

export default function HomePage(){
const [students,setStudents]=useState([]);

useEffect(()=>{
axios.get('http://localhost:5000/api/students')
.then(res=>setStudents(res.data.data));
},[]);

return(
<div>
<h1>Students</h1>
{students.map(s=><div key={s._id}>{s.name}</div>)}
</div>
);
}
