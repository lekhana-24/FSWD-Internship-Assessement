const Student = require('../models/Student');

const formatErrors = (err) => {
  if (err.code === 11000) return { message: "Duplicate field" };
  if (err.name === "ValidationError") {
    let errors = {};
    Object.values(err.errors).forEach(e => errors[e.path] = e.message);
    return errors;
  }
  return { message: "Error" };
};

exports.getAll = async (req,res)=>{
  const {search,course,year}=req.query;
  let query={};
  if(search) query.$or=[
    {name:new RegExp(search,'i')},
    {email:new RegExp(search,'i')},
    {rollNumber:new RegExp(search,'i')}
  ];
  if(course) query.course=course;
  if(year) query.year=year;

  const data=await Student.find(query);
  res.json({success:true,data});
};

exports.create = async (req,res)=>{
  try{
    const data=await Student.create(req.body);
    res.json({success:true,data});
  }catch(err){
    res.status(400).json({success:false,...formatErrors(err)});
  }
};

exports.getOne = async (req,res)=>{
  const data=await Student.findById(req.params.id);
  res.json({success:true,data});
};

exports.update = async (req,res)=>{
  try{
    const data=await Student.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});
    res.json({success:true,data});
  }catch(err){
    res.status(400).json({success:false,...formatErrors(err)});
  }
};

exports.delete = async (req,res)=>{
  await Student.findByIdAndDelete(req.params.id);
  res.json({success:true,message:"Deleted"});
};
