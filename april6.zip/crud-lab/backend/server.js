require('dotenv').config();
const express=require('express');
const cors=require('cors');
const connectDB=require('./config/db');

const app=express();
connectDB();

app.use(cors({origin:"http://localhost:5173"}));
app.use(express.json());

app.use('/api',require('./routes/api'));

app.listen(5000,()=>console.log("Server running"));
