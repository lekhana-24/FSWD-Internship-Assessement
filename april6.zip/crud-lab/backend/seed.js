require('dotenv').config();
const mongoose=require('mongoose');
const Student=require('./models/Student');

mongoose.connect(process.env.MONGODB_URI).then(async()=>{
  await Student.insertMany([
    {name:"A",email:"a@mail.com",rollNumber:"1",course:"Computer Science",year:1,gpa:8},
    {name:"B",email:"b@mail.com",rollNumber:"2",course:"IT",year:2,gpa:7}
  ]);
  console.log("seeded");
  mongoose.disconnect();
});
