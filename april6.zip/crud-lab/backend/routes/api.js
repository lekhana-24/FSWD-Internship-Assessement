const router=require('express').Router();
const ctrl=require('../controllers/studentController');

router.get('/students',ctrl.getAll);
router.post('/students',ctrl.create);
router.get('/students/:id',ctrl.getOne);
router.put('/students/:id',ctrl.update);
router.delete('/students/:id',ctrl.delete);

module.exports=router;
